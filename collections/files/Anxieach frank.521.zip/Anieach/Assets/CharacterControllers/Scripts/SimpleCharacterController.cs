﻿/* ====================================================================================================
Simple Character Controller
---

This is a character controller script for Unity. It uses the built-in CharacterController component.
 
---
Andrew Frueh. 
CC BY-NC 4.0 - https://creativecommons.org/licenses/by-nc/4.0/
==================================================================================================== */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimpleCharacterController : MonoBehaviour
{
    public CharacterController characterController;
    public Camera cameraToControl;

    public float speed = 6.0f;
    public float jumpSpeed = 8.0f;
    public float gravity = 20.0f;

    private Vector3 moveDirection = Vector3.zero;

    public float lookSpeed = 3;
    private Vector2 rotation = Vector2.zero;

    void Start()
    {
        characterController = GetComponent<CharacterController>();
    }

    void Update()
    {
        if (characterController.isGrounded)
        {
            // We are grounded, so recalculate
            // move direction directly from axes

            moveDirection = transform.forward * Input.GetAxis("Vertical") * speed;
            moveDirection += transform.right * Input.GetAxis("Horizontal") * speed;

            if (Input.GetButton("Jump"))
            {
                moveDirection.y = jumpSpeed;
            }
        }

        // Apply gravity. Gravity is multiplied by deltaTime twice (once here, and once below
        // when the moveDirection is multiplied by deltaTime). This is because gravity should be applied
        // as an acceleration (ms^-2)
        moveDirection.y -= gravity * Time.deltaTime;

        // Mouse input / head movement
        rotation.y += Input.GetAxis("Mouse X");
        rotation.x += -Input.GetAxis("Mouse Y");
        rotation.x = Mathf.Clamp(rotation.x, -15f, 15f);
        // look left / right
        transform.localRotation = Quaternion.Euler(0, rotation.y * lookSpeed, 0);
        // look up / down
        cameraToControl.transform.localRotation = Quaternion.Euler(rotation.x * lookSpeed, 0, 0);

        // Move the controller
        characterController.Move(moveDirection * Time.deltaTime);
    }
}
