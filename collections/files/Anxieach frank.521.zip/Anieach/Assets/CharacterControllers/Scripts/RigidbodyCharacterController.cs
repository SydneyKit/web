﻿/* ====================================================================================================
Rigidbody Character Controller
---

This is a character controller script for Unity. It uses the built-in Rigidbody component.
 
---
Andrew Frueh. 
CC BY-NC 4.0 - https://creativecommons.org/licenses/by-nc/4.0/
==================================================================================================== */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RigidbodyCharacterController : MonoBehaviour
{
    public Rigidbody characterRigidbody;
    public Camera cameraToControl;

    public float moveSpeed = 6.0f;
    public float jumpSpeed = 8.0f;

    private Vector3 moveVector = Vector3.zero;

    public float lookSpeed = 3;
    private Vector2 rotation = Vector2.zero;

    public float maxSpeed = 2f;
    //public float maxJumpSpeed = 10f;

    private float DisstanceToTheGround;
    //public float jumpDelayTime = 0.5f;
    private bool isGrounded;
    private bool isColliding;
    private bool isJumping;

    public ForceMode moveForceMode;

    void Start()
    {
        characterRigidbody = GetComponent<Rigidbody>();
        DisstanceToTheGround = GetComponent<Collider>().bounds.extents.y;
    }

    void OnCollisionStay()
    {
        isColliding = true;
    }

    void OnCollisionExit()
    {
        isColliding = false;
    }



    void Update()
    {

        moveVector = Vector3.zero;

        isGrounded = Physics.Raycast(transform.position, Vector3.down, DisstanceToTheGround + 0.1f);

        moveVector = transform.forward * Input.GetAxis("Vertical") * moveSpeed;
        moveVector += transform.right * Input.GetAxis("Horizontal") * moveSpeed;

        if (isGrounded)
        {
            // We are grounded, so recalculate
            // move direction directly from axes

            if (Input.GetButtonDown("Jump"))//&& isColliding)// && !isJumping) //characterRigidbody.velocity.y == 0)
            {
                moveVector.y = jumpSpeed;
            }
        }
        else
        {
            // Do nothing
        }
        
        // Mouse input / head movement
        rotation.y += Input.GetAxis("Mouse X");
        rotation.x += -Input.GetAxis("Mouse Y");
        rotation.x = Mathf.Clamp(rotation.x, -15f, 15f);
        // look left / right
        transform.localRotation = Quaternion.Euler(0, rotation.y * lookSpeed, 0);
        // look up / down
        cameraToControl.transform.localRotation = Quaternion.Euler(rotation.x * lookSpeed, 0, 0);

        // Move the controller
        characterRigidbody.AddForce(moveVector , moveForceMode);
        // clamp velocity:
        Vector3 newVelocity = characterRigidbody.velocity.normalized;

        newVelocity.x *= maxSpeed;
        newVelocity.y = characterRigidbody.velocity.y;//*= maxJumpSpeed;
        newVelocity.z *= maxSpeed;
        characterRigidbody.velocity = newVelocity;

    }


}
