# Character Controllers

These simplified character controllers are developed for my students. They only have the bare minimum to cause the least conflicts. Compatibility is geared toward desktop input and WebGL.

## Installation

Use the Import Package option from within Unity.

## Usage

Just grab one of the prefabs in the Prefabs folder. The Simple Character uses the built in Character Controller component. The Rigidbody Character uses the built in Rigidbody compoennt.

## Contributing
n/a

## License
Andrew Frueh. 
CC BY-NC 4.0 - https://creativecommons.org/licenses/by-nc/4.0/
