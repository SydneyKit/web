﻿/* ====================================================================================================
	A simple script will switch to the scene named in the sceneName property upon collision with the
	object this script is attached to. This object must also have a rigidBody (can be "trigger"). 

	Note that with the tagName property you can use this single object to change to different scenes
	by attaching multiple instances of this component.
 
---
Andrew Frueh. 
CC BY-NC 4.0 - https://creativecommons.org/licenses/by-nc/4.0/
Modified: 2019-01-05
==================================================================================================== */


using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadSceneOnCollision : MonoBehaviour {

	[Tooltip("Name of the scene to load.")]
	public string sceneName;

	[Tooltip("Only trigger if the object has this tag.")]
	public string tagName;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnCollisionEnter(Collision other){
		if(tagName=="" || tagName==other.transform.tag){
			SceneManager.LoadScene(sceneName);
		}
	}

	void OnTriggerEnter(Collider other){
		if(tagName=="" || tagName==other.transform.tag){
			SceneManager.LoadScene(sceneName);
		}
	}

}
