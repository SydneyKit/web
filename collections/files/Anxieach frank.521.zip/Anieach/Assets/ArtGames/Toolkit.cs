﻿/* ====================================================================================
   These are handy functions I got used to having in other environments. 
---

	Public Properties:
		None
		
	Public Methods:
		Map()
		Constrain()

---
Andrew Frueh
CC BY-NC 4.0 - https://creativecommons.org/licenses/by-nc/4.0/
Modified: 2018-12-13
==================================================================================== */

using UnityEngine;

public static class Toolkit
{
    
    // Translated from Arduino
    public static float Map(float x, float in_min, float in_max, float out_min, float out_max)
    {
        return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
    }

    // Translated from Arduino
    public static float Constrain(float x, float min, float max)
    {
        return (x > min) ? ((x < max) ? x : max) : min;
    }
    
}
