﻿/* ====================================================================================================
	A simple script will switch to the scene named in the sceneName property upon input from the keyboard. 

	Note that with the tagName property you can use this single object to change to different scenes
	by attaching multiple instances of this component.
 
---
Andrew Frueh. 
CC BY-NC 4.0 - https://creativecommons.org/licenses/by-nc/4.0/
Modified: 2019-01-05
==================================================================================================== */


using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadSceneOnInput : MonoBehaviour {

	[Tooltip("Name of the scene to load.")]
	public string sceneName;

	[Tooltip("Time (in seconds) to wait before allowing the keyboard input.")]
	public float loadDelay = 2f;

	private Timer delayTimer = new Timer();

	[Tooltip("If true, user can press any key to trigger.")]
	public bool pressAnyKey = true;

	[Tooltip("If pressAnyKey is false (above), only trigger if this specific key is pressed.")]
	public char keyToPress = 'a';

	// Use this for initialization
	void Start () {
		delayTimer.SetRate(loadDelay);
		delayTimer.Reset();
	}
	
	// Update is called once per frame
	void Update () {
		// if the delay time has passed
		if( delayTimer.Timeout() ){
			if( (pressAnyKey&&Input.anyKeyDown) || Input.GetKeyDown (keyToPress.ToString())){
				delayTimer.Reset();
				SceneManager.LoadScene(sceneName);
			}
		}
	}
}
