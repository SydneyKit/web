﻿/* ====================================================================================================
	This Timer class allows you to create simple timers. A common implementation is to us an if() 
	to check Interval(). This allows you to lower load on the CPU by spreading out tasks at a lower 
	clock rate. Also, you can use GetTimeRatio() to achieve a simple linear lerp.

	To update the timer, you must call one of the following: Interval() or Timeout()
	Interval() is for a repeating item. It calls Reset().
	Timeout() is for one-time events. It does not call Reset().

Public Properties:
	None
	
Public methods:
	Interval() -- Use for repeating events. Returns false until triggered, then returns true only once, then auto-resets to false when read.
	Timeout() -- Use for single-run (terminal) events. Returns false until triggered, then returns true until reset.
	Reset() -- Resets the timer to zero. Cycle count is maintained.
	SetRate() -- Use any unit system to set the duration of the timer. Returns nothing.
	GetRate() -- Returns the current rate of the timer.
	GetCycles() -- Returns how many cycles have passed since the timer was started.
	GetTimeElapsed() -- Returns milliseconds passed since timer started (or last reset)
	GetTimeRemaining() -- Returns milliseconds until the timer will trigger
	GetTimeRatio() -- Returns float 0-1 representing how long until the next trigger time
 
---
Andrew Frueh. 
CC BY-NC 4.0 - https://creativecommons.org/licenses/by-nc/4.0/
Modified: 2019-02-12
==================================================================================================== */

using UnityEngine;

public class Timer 
{

	//
	private float _lastTime;
	private float _rate; 
	private int _cycles;
	private bool _interval;

    public Timer (float rate=1f)
    {
        SetRate(rate);
		//Start();
    }

	void Start () 
	{
		_lastTime = Time.time;
		_cycles = 0;
		//_rate = 1; 
		_interval = false;
	}

	public void SetRate(float newRate = 1)
	{
		_rate = newRate;
	}

	public float GetRate()
	{
		return _rate;
	}


	public int GetCycles()
	{
		//Update();
		return _cycles;
	}


    public float GetTimeElapsed()
    {
		//Update();
        //return ( (Time.time - _lastTime) % _rate ); // this is bad. This will roll-over the rate due to %. And if you reset, then it snaps to 0.
        return Toolkit.Constrain( (Time.time - _lastTime), 0, _rate ); // This will clamp to the rate and not roll over.
    }

    public float GetTimeRemaining()
    {
		//Update();
        return _rate - GetTimeElapsed();
    }

	public float GetTimeRatio(){
        //return Toolkit.Map( GetTimeElapsed(), 0, _rate, 0, 1);
		return GetTimeElapsed() / GetRate();
	}

	public bool Interval(){
		if( CheckTime() ){
			Reset();
			return true;
		}else{
			return false;
		}
	}

	public bool Timeout(){
		if( CheckTime() ){
			//Reset();
			return true;
		}else{
			return false;
		}
	}

    public void Reset(){
		_lastTime = Time.time;
		_cycles++;
		_interval = false;
	}

	private bool CheckTime(){
		if( Time.time - _lastTime >= _rate ){
			return true;
		}else{
			return false;
		}
	}



}
